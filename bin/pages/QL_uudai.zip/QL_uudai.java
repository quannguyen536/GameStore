package pages;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import swings.PlaceholderTextFields;
import swings.PlaceholderTextFields;

import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class QL_uudai extends JPanel{
	private JTextField tf_timkiem;
	private JTextField textField_1;
	private JTextField tf_sodiem;
	public QL_uudai() {
		setBackground(new Color(255, 255, 255));
		setSize(1170, 900);	
		setLayout(null);
		
		JLabel lb_title_uudai = new JLabel("");
		lb_title_uudai.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/logos/tieudeuudai.png")));
		lb_title_uudai.setFont(new Font("Tahoma", Font.BOLD, 30));
		lb_title_uudai.setHorizontalAlignment(SwingConstants.CENTER);
		lb_title_uudai.setBounds(240, 211, 680, 120);
		add(lb_title_uudai);
		
		tf_sodiem = new JTextField();
		tf_sodiem.setForeground(new Color(255, 204, 0));
		tf_sodiem.setFont(new Font("Tahoma", Font.BOLD, 20));
		tf_sodiem.setBackground(new Color(0,28,65));
		tf_sodiem.setBounds(184, 352, 125, 30);
		add(tf_sodiem);
		tf_sodiem.setColumns(10);
		
		
		JLabel lblNewLabel = new JLabel("Điểm:");
		lblNewLabel.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/icons/icons8-coin-35.png")));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 204, 0));
		lblNewLabel.setBounds(79, 349, 104, 41);
		add(lblNewLabel);
		
		JLabel ic_timkiem = new JLabel("");
		ic_timkiem.setHorizontalAlignment(SwingConstants.CENTER);
		ic_timkiem.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/icons/icons8-search-35.png")));
		ic_timkiem.setBounds(643, 352, 53, 30);
		add(ic_timkiem);
		
	
		tf_timkiem = new PlaceholderTextFields("Nhập thông tin cần tìm...");
		tf_timkiem.setBackground(new Color(0,28,65));
		tf_timkiem.setBounds(347, 349, 300, 35);
		add(tf_timkiem);
		tf_timkiem.setColumns(10);
		
		
		JLabel lb_diem = new JLabel("45000");
		lb_diem.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/icons/icons8-coin-18.png")));
		lb_diem.setBackground(new Color(204, 204, 204));
		lb_diem.setOpaque(true);
		lb_diem.setForeground(new Color(255, 0, 0));
		lb_diem.setFont(new Font("Tahoma", Font.BOLD, 13));
		lb_diem.setBounds(102, 487, 155, 23);
		add(lb_diem);
		

		
		JLabel lb_anh = new JLabel("");
		lb_anh.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/uudais/sushi137.jpg")));
		lb_anh.setBackground(new Color(102, 102, 255));
		lb_anh.setOpaque(true);
		lb_anh.setBounds(112, 521, 135, 103);
		add(lb_anh);

		JLabel lb_title = new JLabel("Sushi");
		lb_title.setForeground(new Color(0, 0, 102));
		lb_title.setFont(new Font("Tahoma", Font.BOLD, 16));
		lb_title.setHorizontalAlignment(SwingConstants.CENTER);
		lb_title.setBackground(new Color(204, 204, 255));
		lb_title.setOpaque(true);
		lb_title.setBounds(122, 628, 116, 30);
		add(lb_title);
		
		
		JLabel bt_doisushi = new JLabel("Đổi");
		bt_doisushi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				bt_doisushi.setBackground(new Color(204,0,1));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				bt_doisushi.setBackground(new Color(255,1,1));
			}
		});
		bt_doisushi.setForeground(new Color(255, 255, 255));
		bt_doisushi.setFont(new Font("Tahoma", Font.BOLD, 15));
		bt_doisushi.setBackground(new Color(255,1,1));
		bt_doisushi.setOpaque(true);
		bt_doisushi.setHorizontalAlignment(SwingConstants.CENTER);
		bt_doisushi.setBounds(102, 663, 155, 30);
		add(bt_doisushi);
		
		
		JLabel lb_qua1 = new JLabel("");
		lb_qua1.setBackground(new Color(255, 255, 255));
		lb_qua1.setOpaque(true);
		lb_qua1.setBounds(90, 475, 177, 225);
		add(lb_qua1);

		JLabel lb_diem_1 = new JLabel("10000");
		lb_diem_1.setOpaque(true);
		lb_diem_1.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/icons/icons8-coin-18.png")));
		lb_diem_1.setForeground(Color.RED);
		lb_diem_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lb_diem_1.setBackground(new Color(204, 204, 204));
		lb_diem_1.setBounds(312, 487, 155, 23);
		add(lb_diem_1);
		
		JLabel lb_anh_1 = new JLabel("");
		lb_anh_1.setOpaque(true);
		lb_anh_1.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/uudais/tradao137.jpg")));
		lb_anh_1.setBackground(new Color(102, 102, 255));
		lb_anh_1.setBounds(322, 521, 135, 103);
		add(lb_anh_1);
		
		JLabel lb_title_1 = new JLabel("Trà đào");
		lb_title_1.setOpaque(true);
		lb_title_1.setHorizontalAlignment(SwingConstants.CENTER);
		lb_title_1.setForeground(new Color(0, 0, 102));
		lb_title_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lb_title_1.setBackground(new Color(204, 204, 255));
		lb_title_1.setBounds(332, 628, 116, 30);
		add(lb_title_1);
		
		JLabel bt_doitradao = new JLabel("Đổi");
		bt_doitradao.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				bt_doitradao.setBackground(new Color(204,0,1));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				bt_doitradao.setBackground(new Color(255,1,1));
			}
		});
		bt_doitradao.setOpaque(true);
		bt_doitradao.setHorizontalAlignment(SwingConstants.CENTER);
		bt_doitradao.setForeground(Color.WHITE);
		bt_doitradao.setFont(new Font("Tahoma", Font.BOLD, 15));
		bt_doitradao.setBackground(new Color(255, 1, 1));
		bt_doitradao.setBounds(312, 663, 155, 30);
		add(bt_doitradao);
		
		JLabel lb_qua1_1 = new JLabel("");
		lb_qua1_1.setOpaque(true);
		lb_qua1_1.setBackground(Color.WHITE);
		lb_qua1_1.setBounds(300, 475, 177, 225);
		add(lb_qua1_1);
		
		JLabel lb_diem_2 = new JLabel("10000");
		lb_diem_2.setOpaque(true);
		lb_diem_2.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/icons/icons8-coin-18.png")));
		lb_diem_2.setForeground(Color.RED);
		lb_diem_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lb_diem_2.setBackground(new Color(204, 204, 204));
		lb_diem_2.setBounds(523, 487, 155, 23);
		add(lb_diem_2);
		
		JLabel lb_anh_2 = new JLabel("");
		lb_anh_2.setOpaque(true);
		lb_anh_2.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/uudais/numberone137.png")));
		lb_anh_2.setBackground(new Color(204, 204, 204));
		lb_anh_2.setBounds(533, 521, 135, 103);
		add(lb_anh_2);
		
		JLabel lb_title_2 = new JLabel("Numberone");
		lb_title_2.setOpaque(true);
		lb_title_2.setHorizontalAlignment(SwingConstants.CENTER);
		lb_title_2.setForeground(new Color(0, 0, 102));
		lb_title_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lb_title_2.setBackground(new Color(204, 204, 255));
		lb_title_2.setBounds(543, 628, 116, 30);
		add(lb_title_2);
		
		JLabel bt_doinumberone = new JLabel("Đổi");
		bt_doinumberone.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				bt_doinumberone.setBackground(new Color(204,0,1));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				bt_doinumberone.setBackground(new Color(255,1,1));
			}
		});
		bt_doinumberone.setOpaque(true);
		bt_doinumberone.setHorizontalAlignment(SwingConstants.CENTER);
		bt_doinumberone.setForeground(Color.WHITE);
		bt_doinumberone.setFont(new Font("Tahoma", Font.BOLD, 15));
		bt_doinumberone.setBackground(new Color(255, 1, 1));
		bt_doinumberone.setBounds(523, 663, 155, 30);
		add(bt_doinumberone);
		
		JLabel lb_qua1_2 = new JLabel("");
		lb_qua1_2.setOpaque(true);
		lb_qua1_2.setBackground(Color.WHITE);
		lb_qua1_2.setBounds(512, 475, 177, 225);
		add(lb_qua1_2);
		
		JLabel lb_diem_3 = new JLabel("35000");
		lb_diem_3.setOpaque(true);
		lb_diem_3.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/icons/icons8-coin-18.png")));
		lb_diem_3.setForeground(Color.RED);
		lb_diem_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lb_diem_3.setBackground(new Color(204, 204, 204));
		lb_diem_3.setBounds(735, 487, 155, 23);
		add(lb_diem_3);
		
		JLabel lb_anh_3 = new JLabel("");
		lb_anh_3.setOpaque(true);
		lb_anh_3.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/uudais/hamburger137.jpg")));
		lb_anh_3.setBackground(new Color(102, 102, 255));
		lb_anh_3.setBounds(745, 521, 135, 103);
		add(lb_anh_3);
		
		JLabel lb_title_3 = new JLabel("Hamburger");
		lb_title_3.setOpaque(true);
		lb_title_3.setHorizontalAlignment(SwingConstants.CENTER);
		lb_title_3.setForeground(new Color(0, 0, 102));
		lb_title_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		lb_title_3.setBackground(new Color(204, 204, 255));
		lb_title_3.setBounds(755, 628, 116, 30);
		add(lb_title_3);
		
		JLabel bt_doihamburger = new JLabel("Đổi");
		bt_doihamburger.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				bt_doihamburger.setBackground(new Color(204,0,1));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				bt_doihamburger.setBackground(new Color(255,1,1));
			}
		});
		bt_doihamburger.setOpaque(true);
		bt_doihamburger.setHorizontalAlignment(SwingConstants.CENTER);
		bt_doihamburger.setForeground(Color.WHITE);
		bt_doihamburger.setFont(new Font("Tahoma", Font.BOLD, 15));
		bt_doihamburger.setBackground(new Color(255, 1, 1));
		bt_doihamburger.setBounds(735, 663, 155, 30);
		add(bt_doihamburger);
		
		JLabel lb_qua1_3 = new JLabel("");
		lb_qua1_3.setOpaque(true);
		lb_qua1_3.setBackground(Color.WHITE);
		lb_qua1_3.setBounds(723, 475, 177, 225);
		add(lb_qua1_3);
		
		JLabel lb_diem_3_1 = new JLabel("10000");
		lb_diem_3_1.setOpaque(true);
		lb_diem_3_1.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/icons/icons8-coin-18.png")));
		lb_diem_3_1.setForeground(Color.RED);
		lb_diem_3_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lb_diem_3_1.setBackground(new Color(204, 204, 204));
		lb_diem_3_1.setBounds(947, 487, 155, 23);
		add(lb_diem_3_1);
		
		JLabel lb_anh_3_1 = new JLabel("");
		lb_anh_3_1.setOpaque(true);
		lb_anh_3_1.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/uudais/pepsi137.jpg")));
		lb_anh_3_1.setBackground(new Color(102, 102, 255));
		lb_anh_3_1.setBounds(957, 521, 135, 103);
		add(lb_anh_3_1);
		
		JLabel lb_title_3_1 = new JLabel("Pepsi");
		lb_title_3_1.setOpaque(true);
		lb_title_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lb_title_3_1.setForeground(new Color(0, 0, 102));
		lb_title_3_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lb_title_3_1.setBackground(new Color(204, 204, 255));
		lb_title_3_1.setBounds(967, 628, 116, 30);
		add(lb_title_3_1);
		
		JLabel bt_doipepsi = new JLabel("Đổi");
		bt_doipepsi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				bt_doipepsi.setBackground(new Color(204,0,1));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				bt_doipepsi.setBackground(new Color(255,1,1));
			}
		});
		bt_doipepsi.setOpaque(true);
		bt_doipepsi.setHorizontalAlignment(SwingConstants.CENTER);
		bt_doipepsi.setForeground(Color.WHITE);
		bt_doipepsi.setFont(new Font("Tahoma", Font.BOLD, 15));
		bt_doipepsi.setBackground(new Color(255, 1, 1));
		bt_doipepsi.setBounds(947, 663, 155, 30);
		add(bt_doipepsi);
		
		JLabel lb_qua1_3_1 = new JLabel("");
		lb_qua1_3_1.setOpaque(true);
		lb_qua1_3_1.setBackground(Color.WHITE);
		lb_qua1_3_1.setBounds(935, 475, 177, 225);
		add(lb_qua1_3_1);
		
		JLabel lb_background_uudai = new JLabel("");
		lb_background_uudai.setFont(new Font("Tahoma", Font.BOLD, 20));
		lb_background_uudai.setHorizontalAlignment(SwingConstants.RIGHT);
		lb_background_uudai.setForeground(new Color(255, 204, 0));
		lb_background_uudai.setIcon(new ImageIcon(QL_uudai.class.getResource("/images/logos/background3.png")));
		lb_background_uudai.setBounds(0, 0, 1170, 900);
		add(lb_background_uudai);
		

	}
}
